import ReactDOM from 'react-dom/client';
import {AgChartsReact} from 'ag-charts-react';
import {useState} from "react";

export default function Charts() {
    return (
        <div className={"charts"}>
            <h2 id={"infoHeader"}>Information Visualization</h2>
            <div>
            </div>

        </div>
    )
}
