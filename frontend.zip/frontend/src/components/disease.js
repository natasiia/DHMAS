export default function Disease() {
    return (
        <div>
            <h3>Disease</h3>
            <ul>
                <li>Heart:100</li>
                <li>Liver:100</li>
            </ul>
        </div>
    )
}