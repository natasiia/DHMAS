export default function Gender() {
    return (
        <div>
            <h3>Gender</h3>
            <ul>
                <li>Famela:100</li>
                <li>Mela:100</li>
            </ul>
        </div>
    )
}