//
export default function Filters() {
    return (
        <div className={"filters"}>
            <h2 align={"center"}>Filters</h2>

            <label>
                Gender:
                <select
                    name="gender"
                >
                    <option value="">All</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </label>
            <label>
                Diagnosis:
                <select name="diagnosis">
                    <option value="">All</option>
                    <option value="Heart Disease">Heart Disease</option>
                    <option value="Cancer">Cancer</option>
                </select>
            </label>
            <label>
                Medication:
                <select name="medication">
                    <option value="">All</option>
                    <option value="Aspirin">Aspirin</option>
                    <option value="Antibiotics">Antibiotics</option>
                    {/* Add other medication options */}
                </select>
            </label>
            <label>
                Insurance Type:
                <select name="insuranceType">
                    <option value="">All</option>
                    <option value="Private">Private</option>
                    <option value="Uninsured">Uninsured</option>
                    {/* Add other insurance type options */}
                </select>
            </label>
            <div align={"center"}>
                <button>Apply</button>
            </div>
        </div>
    )
}
//
// import React from "react";
//
// export default function Filters({ onFilterChange }) {
//     const handleFilterChange = (e) => {
//         const { name, value } = e.target;
//         onFilterChange({ [name]: value });
//     };
//
//     return (
//         <div className="filters">
//             <h2 align="center">Filters</h2>
//
//             <label>
//                 Gender:
//                 <select name="gender" onChange={handleFilterChange}>
//                     <option value="">All</option>
//                     <option value="Male">Male</option>
//                     <option value="Female">Female</option>
//                 </select>
//             </label>
//             <label>
//                 Diagnosis:
//                 <select name="diagnosis" onChange={handleFilterChange}>
//                     <option value="">All</option>
//                     <option value="Heart Disease">Heart Disease</option>
//                     <option value="Cancer">Cancer</option>
//                     {/* Add other diagnosis options */}
//                 </select>
//             </label>
//             <label>
//                 Medication:
//                 <select name="medication" onChange={handleFilterChange}>
//                     <option value="">All</option>
//                     <option value="Aspirin">Aspirin</option>
//                     <option value="Antibiotics">Antibiotics</option>
//                     {/* Add other medication options */}
//                 </select>
//             </label>
//             <label>
//                 Insurance Type:
//                 <select name="insuranceType" onChange={handleFilterChange}>
//                     <option value="">All</option>
//                     <option value="Private">Private</option>
//                     <option value="Uninsured">Uninsured</option>
//                     {/* Add other insurance type options */}
//                 </select>
//             </label>
//             <div align="center">
//                 <button>Apply</button>
//             </div>
//         </div>
//     );
// }