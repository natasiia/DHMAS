// export default function AddPatient() {
//     return (
//         <div className={"addPatient"}>
//             <h2 align={"center"}>New Patient</h2>
//             <div>
//                 <form>
//                     <label>
//                         Age:
//                         <input name={"age"}/>
//                     </label>
//
//                     <label>
//                         Gender:
//                         <input name={"gender"}/>
//                     </label>
//
//                     <label>
//                         Diagnosis:
//                         <input name={"diagnosis"}/>
//                     </label>
//
//                     <label>
//                         Medication:
//                         <input name={"medication"}/>
//                     </label>
//
//                     <label>
//                         InsuranceType:
//                         <input name={"insuranceType"}/>
//                     </label>
//
//                     <label>
//                         Treatment Duration:
//                         <input name={"treatmentDuration"}/>
//                     </label>
//
//                     <label>
//                         E-mail:
//                         <input name={"email"}/>
//                     </label>
//                 </form>
//                 <div align={'center'} className={'submit'}>
//                     <button>Submit</button>
//                 </div>
//             </div>
//         </div>
//     )
// }

import React, {useState} from 'react';

export default function AddPatient() {
    const [formData, setFormData] = useState({
        age: null,
        gender: '',
        diagnosis: '',
        medication: '',
        insuranceType: '',
        treatmentDuration: null,
        email: '',
    });

    const handleChange = (e) => {
        const {name, value} = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await fetch('http://localhost:8083/api/generalInfo', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData),
            });

            if (!response.ok) {
                throw new Error('Submission failed');
            }

            // Handle success (e.g., show a success message)
        } catch (error) {
            console.error('Error submitting data:', error);
            // Handle error (e.g., show an error message)
        }
    };

    return (
        <div className="addPatient">
            <h2 align="center">New Patient</h2>
            <div>
                <form onSubmit={handleSubmit}>
                    <label>
                        Age:
                        <input name={"age"} value={formData.age} onChange={handleChange}/>
                    </label>

                    <label>
                        Gender:
                        <input name={"gender"} value={formData.gender} onChange={handleChange}/>
                    </label>

                    <label>
                        Diagnosis:
                        <input name={"diagnosis"} value={formData.diagnosis} onChange={handleChange}/>
                    </label>

                    <label>
                        Medication:
                        <input name={"medication"} value={formData.medication} onChange={handleChange}/>
                    </label>

                    <label>
                        InsuranceType:
                        <input name={"insuranceType"} value={formData.insuranceType} onChange={handleChange}/>
                    </label>

                    <label>
                        Treatment Duration:
                        <input name={"treatmentDuration"} value={formData.treatmentDuration} onChange={handleChange}/>
                    </label>

                    <label>
                        E-mail:
                        <input name={"email"} value={formData.email} onChange={handleChange}/>
                    </label>
                    <div align="center" className="submit">
                        <button type="submit">Submit</button>

                    </div>
                </form>
            </div>
        </div>
    );
}
