import Gender from "./gender";
import Disease from "./disease";
import React from "react";

export default function Summary(){
    return (
        <div className={"summary"}>
            <h2 align={"center"}>Summary</h2>
            <Gender/>
            <Disease/>
        </div>
    )
}