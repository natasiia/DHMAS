// export default function Header() {
//     return (
//         <div>
//             <h1 align={"center"}>DHMAS Dashboard</h1>
//         </div>
//     )
// }
export default function Header() {
    const headerStyle = {
        backgroundColor: '#4169E1',
        color: 'white',
        textAlign: 'center',
        padding: '10px 0'
    };

    return (
        <div style={headerStyle}>
            <h1>🏥 DHMAS Dashboard 🏥</h1>
        </div>
    )
}


