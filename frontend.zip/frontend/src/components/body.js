import React, {useState, useEffect, useContext} from 'react';
import Filters from "./filters";
import Gender from "./gender";
import Disease from "./disease";
import {AgChartsReact} from "ag-charts-react";
import MailhogContent from './MailhogContent'
import SendEmailForm from "./SendEmailForm";
export default function Body() {
    const [data, setData] = useState();
    const [patients, setPatients] = useState([]);

    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const username = 'pms';
    const password = 'pms-123';
    const basicAuthToken = btoa(`${username}:${password}`);
    const apiUrl = '/api/generalInfo';


    const [filters, setFilters] = useState({
        gender: '',
        diagnosis: '',
        medication: '',
        insuranceType: '',
    });

    const [formData, setFormData] = useState({
        age: null,
        gender: '',
        diagnosis: '',
        medication: '',
        insuranceType: '',
        treatmentDuration: null,
        email: '',
    });

    const [summary, setSummary] = useState(
        {
            female: 0,
            male: 0,
            heart_disease: 0,
            cancer: 0,
            diabetes: 0,
            influenza: 0,
            hypertension: 0,
            private: 0,
            uninsured: 0,
            medicaid: 0,
            medicare: 0
        }
    )
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 10;
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = patients.slice(indexOfFirstItem, indexOfLastItem);
    const totalPages = Math.ceil(patients.length / itemsPerPage);

    const handleChange = (e) => {
        const {name, value} = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await fetch('/api/generalInfo', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData),
            });

            if (!response.ok) {
                throw new Error('Submission failed');
            }

            // Handle success (e.g., show a success message)
        } catch (error) {
            console.error('Error submitting data:', error);
            // Handle error (e.g., show an error message)
        }
    };

    const countOccurrences = (data, conditions) => {
        const counts = {};

        conditions.forEach(({property, targetValue}) => {
            counts[targetValue] = 0;

            data.forEach(patient => {
                if (patient[property] === targetValue) {
                    counts[targetValue]++;
                }
            });
        });

        setSummary({
            ...summary,
            female: counts["Female"],
            male: counts["Male"],
            cancer: counts["Cancer"],
            heart_disease: counts["Heart Disease"],
            diabetes: counts["Diabetes"],
            influenza: counts["Influenza"],
            hypertension: counts["Hypertension"],
            private: counts["Private"],
            uninsured: counts["Uninsured"],
            medicaid: counts["Medicaid"],
            medicare: counts["Medicare"]
        })
    };

    const conditionsArray = [
        {property: 'gender', targetValue: 'Female'},
        {property: 'gender', targetValue: 'Male'},
        {property: 'diagnosis', targetValue: 'Heart Disease'},
        {property: 'diagnosis', targetValue: 'Cancer'},
        {property: 'diagnosis', targetValue: 'Diabetes'},
        {property: 'diagnosis', targetValue: 'Influenza'},
        {property: 'diagnosis', targetValue: 'Hypertension'},
        {property: 'insuranceType', targetValue: 'Private'},
        {property: 'insuranceType', targetValue: 'Uninsured'},
        {property: 'insuranceType', targetValue: 'Medicaid'},
        {property: 'insuranceType', targetValue: 'Medicare'},
        // Add more conditions as needed
    ];
    const fetchData = async () => {
        try {
            const response = await fetch(apiUrl, {
                method: 'GET',
                headers: {
                    'Authorization': `Basic ${basicAuthToken}`,
                    'Content-Type': 'application/json',
                },
            });

            if (!response.ok) {
                throw new Error('Load failure');
            }

            const patientsData = await response.json();
            setData(patientsData);
            setPatients(patientsData)
            countOccurrences(patientsData, conditionsArray)
            setLoading(false);
        } catch (error) {
            setError(error.message);
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, []); // Empty dependency array ensures that the effect runs once, similar to componentDidMount

    // useEffect(() => {
    //     fetch('http://localhost:8025/api/v1/messages')
    //         .then(response => response.json())
    //         .then(data => {
    //             setMailhogData(data);
    //         })
    //         .catch(error => {
    //             console.error('Error fetching data: ', error);
    //         });
    // }, []);

    if (loading) {
        return <div>Loading...</div>;
    }

    if (error) {
        return <div>Error: {error}</div>;
    }

    function handleFilterClick() {
        const filteredData = patients.filter(item => {
            return (
                (filters.gender === '' || item.gender === filters.gender) &&
                (filters.diagnosis === '' || item.diagnosis === filters.diagnosis) &&
                (filters.medication === '' || item.medication === filters.medication) &&
                (filters.insuranceType === '' || item.insuranceType === filters.insuranceType)
            );
        })
        setPatients(filteredData)
    }

    function handleResetClick() {
        setFilters({
            gender: '',
            diagnosis: '',
            medication: '',
            insuranceType: '',
        });
        setPatients(data)

    }

    function handleSubmitClick() {
        fetchData();
    }

    const handlePageChange = (page) => {
        setCurrentPage(page);
    };

    const renderPageNumbers = () => {
        let pageNumbers = [];

        for (let i = 1; i <= totalPages; i++) {
            pageNumbers.push(
                <span
                    key={i}
                    onClick={() => handlePageChange(i)}
                    className={`page-number ${i === currentPage ? 'active' : ''}`}
                >
        {i}
      </span>
            );
        }

        return pageNumbers;
    };

    //charts
    const BarForAge = () => {
        let ages = patients.map(patient => ({age: patient.age}))
        const [options, setOptions] = useState({
            title: {
                text: 'Age Distribution',
            },
            data: ages,
            series: [
                {
                    type: 'histogram',
                    xKey: 'age',
                    xName: 'Participant Age',
                },
            ],
            axes: [
                {
                    type: 'number',
                    position: 'bottom',
                    title: {text: 'Age band (years)'},
                    tick: {interval: 2},
                },
                {
                    type: 'number',
                    position: 'left',
                    title: {text: 'Number of patients'},
                },
            ],
        });
        return <AgChartsReact options={options}/>;
    }

    const BarForDisease = () => {
        const counts = {
            "Female": {
                "Heart Disease": 0,
                "Diabetes": 0,
                "Influenza": 0,
                "Cancer": 0,
                "Hypertension": 0,
            },
            "Male": {
                "Heart Disease": 0,
                "Diabetes": 0,
                "Influenza": 0,
                "Cancer": 0,
                "Hypertension": 0,
            },
        };
        patients.forEach(patient => {
            const gender = patient.gender
            const diagnosis = patient.diagnosis
            console.log('Gender:', gender, 'Diagnosis:', diagnosis);
            if (!counts[gender][diagnosis]) {
                counts[gender][diagnosis] = 1
            } else {
                counts[gender][diagnosis]++
            }
        })

        const diseaseData = [
            {
                gender: "Female",
                HeartDisease: counts["Female"]["Heart Disease"],
                Diabetes: counts["Female"]["Diabetes"],
                Influenza: counts["Female"]["Influenza"],
                Cancer: counts["Female"]["Cancer"],
                Hypertension: counts["Female"]["Hypertension"],
            },
            {
                gender: "Male",
                HeartDisease: counts["Male"]["Heart Disease"],
                Diabetes: counts["Male"]["Diabetes"],
                Influenza: counts["Male"]["Influenza"],
                Cancer: counts["Male"]["Cancer"],
                Hypertension: counts["Male"]["Hypertension"],
            },
        ];


        const [options, setOptions] = useState({
            title: {
                text: "Gender and Diseases",
            },
            data: diseaseData,
            series: [
                {
                    type: 'bar',
                    xKey: 'gender',
                    yKey: 'HeartDisease',
                    yName: 'HeartDisease',
                },
                {
                    type: 'bar',
                    xKey: 'gender',
                    yKey: 'Diabetes',
                    yName: 'Diabetes',
                },
                {
                    type: 'bar',
                    xKey: 'gender',
                    yKey: 'Influenza',
                    yName: 'Influenza',
                },
                {
                    type: 'bar',
                    xKey: 'gender',
                    yKey: 'Cancer',
                    yName: 'Cancer',
                },
                {
                    type: 'bar',
                    xKey: 'gender',
                    yKey: 'Hypertension',
                    yName: 'Hypertension',
                },

            ]
        });


        return <AgChartsReact options={options}/>;
    };
    const BarForDrugs = () => {
        const counts = {
            "Heart Disease": {
                "Aspirin": 0,
                "Antibiotics": 0,
                "Chemotherapy": 0,
                "Statins": 0,
                "Insulin": 0,
            },
            "Cancer": {
                "Aspirin": 0,
                "Antibiotics": 0,
                "Chemotherapy": 0,
                "Statins": 0,
                "Insulin": 0,
            },
            "Diabetes": {
                "Aspirin": 0,
                "Antibiotics": 0,
                "Chemotherapy": 0,
                "Statins": 0,
                "Insulin": 0,
            },
            "Influenza": {
                "Aspirin": 0,
                "Antibiotics": 0,
                "Chemotherapy": 0,
                "Statins": 0,
                "Insulin": 0,
            },
            "Hypertension": {
                "Aspirin": 0,
                "Antibiotics": 0,
                "Chemotherapy": 0,
                "Statins": 0,
                "Insulin": 0,
            },
        };
        patients.forEach(patient => {
            const drug = patient.medication;
            const diagnosis = patient.diagnosis;

            // Check if medication and diagnosis exist in counts object
            if (counts[diagnosis] && counts[diagnosis][drug] !== undefined) {
                if (!counts[diagnosis][drug]) {
                    counts[diagnosis][drug] = 1;
                } else {
                    counts[diagnosis][drug]++;
                }
            }
        });

        const drugData = [
            {
                diagnosis: "Heart Disease",
                Aspirin: counts["Heart Disease"]["Aspirin"],
                Antibiotics: counts["Heart Disease"]["Antibiotics"],
                Chemotherapy: counts["Heart Disease"]["Chemotherapy"],
                Statins: counts["Heart Disease"]["Statins"],
                Insulin: counts["Heart Disease"]["Insulin"],
            },
            {
                diagnosis: "Cancer",
                Aspirin: counts["Cancer"]["Aspirin"],
                Antibiotics: counts["Cancer"]["Antibiotics"],
                Chemotherapy: counts["Cancer"]["Chemotherapy"],
                Statins: counts["Cancer"]["Statins"],
                Insulin: counts["Cancer"]["Insulin"],
            },
            {
                diagnosis: "Diabetes",
                Aspirin: counts["Diabetes"]["Aspirin"],
                Antibiotics: counts["Diabetes"]["Antibiotics"],
                Chemotherapy: counts["Diabetes"]["Chemotherapy"],
                Statins: counts["Diabetes"]["Statins"],
                Insulin: counts["Diabetes"]["Insulin"],
            },
            {
                diagnosis: "Influenza",
                Aspirin: counts["Influenza"]["Aspirin"],
                Antibiotics: counts["Influenza"]["Antibiotics"],
                Chemotherapy: counts["Influenza"]["Chemotherapy"],
                Statins: counts["Influenza"]["Statins"],
                Insulin: counts["Influenza"]["Insulin"],
            },
            {
                diagnosis: "Hypertension",
                Aspirin: counts["Hypertension"]["Aspirin"],
                Antibiotics: counts["Hypertension"]["Antibiotics"],
                Chemotherapy: counts["Hypertension"]["Chemotherapy"],
                Statins: counts["Hypertension"]["Statins"],
                Insulin: counts["Hypertension"]["Insulin"],
            },
        ];


        const [options, setOptions] = useState({
            title: {
                text: "Medication and Diseases",
            },
            data: drugData,
            series: [
                {
                    type: 'bar',
                    xKey: 'diagnosis',
                    yKey: 'Aspirin',
                    yName: 'Aspirin',
                },
                {
                    type: 'bar',
                    xKey: 'diagnosis',
                    yKey: 'Antibiotics',
                    yName: 'Antibiotics',
                },
                {
                    type: 'bar',
                    xKey: 'diagnosis',
                    yKey: 'Chemotherapy',
                    yName: 'Chemotherapy',
                },
                {
                    type: 'bar',
                    xKey: 'diagnosis',
                    yKey: 'Statins',
                    yName: 'Statins',
                },
                {
                    type: 'bar',
                    xKey: 'diagnosis',
                    yKey: 'Insulin',
                    yName: 'Insulin',
                },

            ]
        });


        return <AgChartsReact options={options}/>;
    };

    console.log(patients[0])
    return (
        <div className={"body"}>

            <div className={"filters"}>
                <h2 align={"center"}>Filters</h2>

                <div className="filters-row">
                    <label>
                        Gender:
                        <select
                            name="gender"
                            onChange={event => (
                                setFilters({
                                    ...filters,
                                    "gender": event.target.value
                                })
                            )}
                        >
                            <option value="">All</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </label>

                    <label>
                        Diagnosis:
                        <select
                            name="diagnosis"
                            onChange={event => (
                                setFilters({
                                    ...filters,
                                    "diagnosis": event.target.value
                                })
                            )}>
                            <option value="">All</option>
                            <option value="Heart Disease">Heart Disease</option>
                            <option value="Cancer">Cancer</option>
                            <option value="Diabetes">Diabetes</option>
                            <option value="Influenza">Influenza</option>
                            <option value="Hypertension">Hypertension</option>
                        </select>
                    </label>

                    <label>
                        Medication:
                        <select
                            name="medication"
                            onChange={event => (
                                setFilters({
                                    ...filters,
                                    "medication": event.target.value
                                })
                            )}
                        >
                            <option value="">All</option>
                            <option value="Aspirin">Aspirin</option>
                            <option value="Antibiotics">Antibiotics</option>
                            <option value="Chemotherapy">Chemotherapy</option>
                            <option value="Statins">Statins</option>
                            <option value="Insulin">Insulin</option>
                            {/* Add other medication options */}
                        </select>
                    </label>

                    <label>
                        Insurance Type:
                        <select
                            name="insuranceType"
                            onChange={event => (
                                setFilters({
                                    ...filters,
                                    "insuranceType": event.target.value
                                })
                            )}
                        >
                            <option value="">All</option>
                            <option value="Private">Private</option>
                            <option value="Uninsured">Uninsured</option>
                            <option value="Medicaid">Medicaid</option>
                            <option value="Medicare">Medicare</option>
                        </select>
                    </label>

                    <div>
                        <button onClick={handleFilterClick}>Apply</button>
                        <button onClick={handleResetClick}>Reset</button>
                    </div>
                </div>
            </div>

            <div className="addPatient">
                <h2 align="center">Add A New Patient</h2>
                <div>
                    <form onSubmit={handleSubmit}>
                        <label>
                            Age:
                            <input name={"age"} value={formData.age} onChange={handleChange}/>
                        </label>

                        <label>
                            Gender:
                            <input name={"gender"} value={formData.gender} onChange={handleChange}/>
                        </label>

                        <label>
                            Diagnosis:
                            <input name={"diagnosis"} value={formData.diagnosis} onChange={handleChange}/>
                        </label>

                        <label>
                            Medication:
                            <input name={"medication"} value={formData.medication} onChange={handleChange}/>
                        </label>

                        <label>
                            InsuranceType:
                            <input name={"insuranceType"} value={formData.insuranceType} onChange={handleChange}/>
                        </label>

                        <label>
                            Treatment Duration:
                            <input name={"treatmentDuration"} value={formData.treatmentDuration}
                                   onChange={handleChange}/>
                        </label>

                        <label>
                            E-mail:
                            <input name={"email"} value={formData.email} onChange={handleChange}/>
                        </label>
                        <div align="center" className="submit">
                            <button type="submit" onClick={handleSubmitClick}>Submit</button>
                        </div>
                    </form>
                </div>
            </div>

            <section className="section-row">
                <div className={"summary"}>
                    <h2 align={"center"}>General Summary</h2>
                    <div>
                        <h3>Gender</h3>
                        <ul>
                            <li>Female:{summary.female}</li>
                            <li>Male:{summary.male}</li>
                        </ul>
                    </div>
                    <div>
                        <h3>Disease</h3>
                        <ul>
                            <li>Heart Disease:{summary.heart_disease}</li>
                            <li>Cancer:{summary.cancer}</li>
                            <li>Diabetes:{summary.diabetes}</li>
                            <li>Influenza:{summary.influenza}</li>
                            <li>Hypertension:{summary.hypertension}</li>

                        </ul>
                    </div>
                    <div>
                        <h3>Insurance Type</h3>
                        <ul>
                            <li>Private:{summary.private}</li>
                            <li>Uninsured:{summary.uninsured}</li>
                            <li>Medicaid:{summary.medicaid}</li>
                            <li>Medicare:{summary.medicare}</li>
                        </ul>
                    </div>
                </div>

                <div className="infoList">
                    <h2 align="center">Patients Information</h2>
                    <div align="center">
                        <table>
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Age</th>
                                <th>Gender</th>
                                <th>Diagnosis</th>
                                <th>Medication</th>
                                <th>InsuranceType</th>
                                <th>Treatment Duration</th>
                                <th>Email</th>
                            </tr>
                            </thead>

                            <tbody>
                            {
                                currentItems.map((patient) => (
                                        <tr key={patient.patientId}>
                                            <td>{patient.patientId}</td>
                                            <td>{patient.age}</td>
                                            <td>{patient.gender}</td>
                                            <td>{patient.diagnosis}</td>
                                            <td>{patient.medication}</td>
                                            <td>{patient.insuranceType}</td>
                                            <td>{patient.treatmentDuration}</td>
                                            <td>{patient.email}</td>
                                        </tr>
                                    )
                                )
                            }
                            </tbody>
                        </table>

                    </div>
                    <div className="pagination">
                        {renderPageNumbers()}
                    </div>
                </div>
            </section>


            <div className="mailhog-content" style={{ backgroundColor: 'beige' }}>
                <MailhogContent />
            </div>
            <section>
                <div className="send-email-div">
                    <SendEmailForm />
                </div>
            </section>
            <div className={"visualization"}>
                <h2 id={"infoHeader" } >Information Visualization</h2>
                <div className={"charts"}>
                    <BarForAge id={"age"}/>
                    <div className={"secondRow"}>
                        <BarForDisease id={"disease"}/>
                        <BarForDrugs id={"drug"}/>
                    </div>
                </div>
            </div>
        </div>
    );

}

