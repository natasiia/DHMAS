import React, { useState, useEffect } from 'react';

// Define the MailhogContent component
const MailhogContent = () => {
    const [messages, setMessages] = useState([]);

    useEffect(() => {
        const fetchMessages = async () => {
            try {
                const response = await fetch('/api/v1/messages');
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                const data = await response.json();
                setMessages(data);
            } catch (error) {
                console.error('There has been a problem with your fetch operation:', error);
            }
        };

        fetchMessages();
        const intervalId = setInterval(fetchMessages, 5000);
        return () => clearInterval(intervalId);
    }, []);

    // Helper function to format the timestamp
    const formatTimestamp = (timestamp) => {
        const date = new Date(timestamp);
        return date.toLocaleString();
    };

    return (
        <div className="mailhog-content" style={{ backgroundColor: 'beige', overflowY: 'auto', overflowX: 'hidden' }}>
            <h2 className="alerting-messages">Real-time Alerting Messages</h2>
            <ul>
                {messages.map((message) => (
                    <li key={message.ID}>
                        <strong>To:</strong> {message.To.map(to => to.Mailbox + '@' + to.Domain).join(', ')}
                        <strong> Subject:</strong> {message.Content.Headers.Subject[0]}
                        <div>{formatTimestamp(message.Created)}</div>
                        <p>{message.Content.Body}</p>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default MailhogContent;
