// import React, {createContext, useContext, useEffect, useState} from "react";
//
// export const DataContext = createContext()
//
// export default function DataContextProvider(props) {
//     const [data, setData] = useState()
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState(null);
//
//     const username = 'pms';
//     const password = 'pms-123';
//     const basicAuthToken = btoa(`${username}:${password}`);
//     const apiUrl = 'http://localhost:8083/api/generalInfo';
//
//     useEffect(() => {
//         const fetchData = async () => {
//             try {
//                 const response = await fetch(apiUrl, {
//                     method: 'GET',
//                     headers: {
//                         'Authorization': `Basic ${basicAuthToken}`,
//                         'Content-Type': 'application/json',
//                     },
//                 });
//
//                 if (!response.ok) {
//                     throw new Error('Load failure');
//                 }
//
//                 const patientsData = await response.json();
//                 setData(patientsData);
//                 setLoading(false);
//             } catch (error) {
//                 setError(error.message);
//                 setLoading(false);
//             }
//         };
//
//         fetchData();
//     }, []);
//     console.log(data)
//     if (loading) {
//         return <div>Loading...</div>;
//     }
//
//     if (error) {
//         return <div>Error: {error}</div>;
//     }
//     return (
//         <DataContext.Provider value={{data, setData}}>
//             {props.children}
//         </DataContext.Provider>
//     )
// }