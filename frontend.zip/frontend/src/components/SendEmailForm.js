import React, { useState } from 'react';

const SendEmailForm = () => {
    const [emailAddress, setEmailAddress] = useState('');
    const [subject, setSubject] = useState('');
    const [content, setContent] = useState('');
    const [responseMessage, setResponseMessage] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await fetch('/api/notification/send-email', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ emailAddress, subject, content }),
            });
            const data = await response.text();
            setResponseMessage(data);
        } catch (error) {
            setResponseMessage('Failed to send email. Error: ' + error.message);
        }
    };

    return (
        <div className="send-email-form" style={{ padding: '20px', border: '1px solid #ccc', margin: '20px 0' }}>
            <h3>Send Email</h3>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Email Address:</label>
                    <input type="email" value={emailAddress} onChange={(e) => setEmailAddress(e.target.value)} required />
                </div>
                <div>
                    <label>Subject:</label>
                    <input type="text" value={subject} onChange={(e) => setSubject(e.target.value)} required />
                </div>
                <div>
                    <label>Content:</label>
                    <textarea value={content} onChange={(e) => setContent(e.target.value)} required />
                </div>
                <button type="submit">Send Email</button>
            </form>
            {responseMessage && <div className="response-message">{responseMessage}</div>}
        </div>
    );
};

export default SendEmailForm;
