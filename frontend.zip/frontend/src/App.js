//import components
import Header from "./components/header";
import Body from "./components/body";

//import css for each component
import './css/App.css';
import './css/index.css';
import './css/body.css'
import './css/summary.css'
import './css/infoList.css'
import './css/filters.css'
import './css/charts.css'
import './css/addPatient.css'
import './css/pagination.css'



function App() {


    return (
        <div className="App">
            <Header/>
            <Body/>
        </div>
    );
}

export default App;
